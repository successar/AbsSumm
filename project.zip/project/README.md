LaTeX Template for Project Report
---------------------------------
_**Version 2.0**_

Abstracted from a Major Project Report at CSED, NIT Calicut but can be
modified easily to use for other reports also.

Released under Creative Commons Attribution license (CC-BY)
Info: http://creativecommons.org/licenses/by/3.0/

### Created by


It is advisable to learn the basics of LaTeX before using this template.
A good resource to start with is http://en.wikibooks.org/wiki/LaTeX/

How to Start
============

Start editing with report.tex and follow the instructions given there.


